import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ==========================================
// 1. DATA MODEL (Session Model)
// ==========================================
class UserSession {
  String name;
  String email;
  String matric;
  String phone;

  UserSession({
    required this.name,
    required this.email,
    required this.matric,
    required this.phone,
  });
}

// ==========================================
// 2. SESSION MANAGER (Persistence Logic)
// ==========================================
class SessionManager {
  static const String keyName = "user_name";
  static const String keyEmail = "user_email";
  static const String keyMatric = "user_matric";
  static const String keyPhone = "user_phone";
  static const String keyIsLogin = "is_login";

  static Future<void> saveSession(UserSession user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(keyIsLogin, true);
    await prefs.setString(keyName, user.name);
    await prefs.setString(keyEmail, user.email);
    await prefs.setString(keyMatric, user.matric);
    await prefs.setString(keyPhone, user.phone);
  }

  static Future<UserSession?> getSession() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(keyIsLogin) ?? false) {
      return UserSession(
        name: prefs.getString(keyName) ?? "User",
        email: prefs.getString(keyEmail) ?? "",
        matric: prefs.getString(keyMatric) ?? "A21EC0000",
        phone: prefs.getString(keyPhone) ?? "+60123456789",
      );
    }
    return null;
  }

  static Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}

// ==========================================
// 3. MAIN APP (Coordinator)
// ==========================================
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  UserSession? session = await SessionManager.getSession();
  runApp(LearnifyApp(initialSession: session));
}

class LearnifyApp extends StatefulWidget {
  final UserSession? initialSession;
  const LearnifyApp({super.key, this.initialSession});

  @override
  State<LearnifyApp> createState() => _LearnifyAppState();
}

class _LearnifyAppState extends State<LearnifyApp> {
  late UserSession _currentSession;

  @override
  void initState() {
    super.initState();
    // Inisialisasi data sesi
    _currentSession = widget.initialSession ?? UserSession(
      name: "Ali bin Ahmad",
      email: "ali.ahmad@student.edu",
      matric: "A21EC0001",
      phone: "+6012-3456789",
    );
  }

  // RECEIVING updated session data from children
  void _handleUpdateSession(UserSession updatedUser) {
    setState(() {
      _currentSession = updatedUser;
    });
    SessionManager.saveSession(updatedUser); // Simpan ke SharedPreferences
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Learnify',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple, primary: Colors.deepPurple),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF8F9FE),
      ),
      // PASSING session data and callback to MainScreen
      home: MainScreen(session: _currentSession, onUpdate: _handleUpdateSession),
    );
  }
}

class MainScreen extends StatefulWidget {
  final UserSession session;
  final Function(UserSession) onUpdate;
  const MainScreen({super.key, required this.session, required this.onUpdate});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      ForumPage(session: widget.session), // Passing session data
      ProfilePage(session: widget.session, onUpdate: widget.onUpdate), // Receiving update via callback
    ];

    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: pages),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: Colors.deepPurple,
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.forum), label: 'Forum'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

// ==========================================
// 4. DATA MODEL (Post)
// ==========================================
class Post {
  final String name;
  final String time;
  final String tag;
  final String question;
  int likes;
  bool isLiked;
  List<String> replies;
  bool showReplyInput;

  Post({
    required this.name,
    required this.time,
    required this.tag,
    required this.question,
    this.likes = 0,
    this.isLiked = false,
    required this.replies,
    this.showReplyInput = false,
  });
}

// ==========================================
// 5. FORUM PAGE (Consumer of Session)
// ==========================================
class ForumPage extends StatefulWidget {
  final UserSession session;
  const ForumPage({super.key, required this.session});

  @override
  State<ForumPage> createState() => _ForumPageState();
}

class _ForumPageState extends State<ForumPage> {
  final TextEditingController _questionController = TextEditingController();
  final TextEditingController _replyController = TextEditingController();

  final List<Post> _posts = [
    Post(
      name: 'Ali bin Ahmad',
      time: '2 mins ago',
      tag: 'Biology',
      question: 'Can someone explain photosynthesis?',
      likes: 12,
      replies: ['It is a process used by plants to convert light energy into chemical energy.'],
    ),
  ];

  void _addNewPost() {
    if (_questionController.text.trim().isNotEmpty) {
      setState(() {
        _posts.insert(
          0,
          Post(
            // MENGGUNAKAN data dari sesi yang dihantar
            name: widget.session.name,
            time: 'Just now',
            tag: 'General',
            question: _questionController.text.trim(),
            replies: [],
          ),
        );
        _questionController.clear();
      });
      FocusScope.of(context).unfocus();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forum', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.deepPurple,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _questionController, decoration: const InputDecoration(hintText: "Ask something..."))),
                IconButton(icon: const Icon(Icons.send, color: Colors.deepPurple), onPressed: _addNewPost),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _posts.length,
              itemBuilder: (context, index) => ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(_posts[index].name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(_posts[index].question),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// 6. PROFILE PAGE (Editor of Session)
// ==========================================
class ProfilePage extends StatefulWidget {
  final UserSession session;
  final Function(UserSession) onUpdate;
  const ProfilePage({super.key, required this.session, required this.onUpdate});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late TextEditingController _nameController;
  late TextEditingController _emailController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.session.name);
    _emailController = TextEditingController(text: widget.session.email);
  }

  void _saveChanges() {
    final updated = UserSession(
      name: _nameController.text,
      email: _emailController.text,
      matric: widget.session.matric,
      phone: widget.session.phone,
    );
    // PASSING data baru balik ke parent
    widget.onUpdate(updated);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Profile Updated!")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Edit Profile")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: _nameController, decoration: const InputDecoration(labelText: "Full Name")),
            TextField(controller: _emailController, decoration: const InputDecoration(labelText: "Email")),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveChanges,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
                child: const Text("SAVE CHANGES"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
