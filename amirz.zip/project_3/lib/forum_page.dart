import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

// ==========================================
// 1. DATA MODELS
// ==========================================

class ForumComment {
  String id;
  String author;
  String text;
  DateTime timestamp;

  ForumComment({
    required this.id,
    required this.author,
    required this.text,
    required this.timestamp,
  });
}

class ForumPost {
  String id;
  String author;
  String content;
  DateTime timestamp;
  int likeCount;
  bool isLiked;
  List<ForumComment> comments;

  ForumPost({
    required this.id,
    required this.author,
    required this.content,
    required this.timestamp,
    this.likeCount = 0,
    this.isLiked = false,
    required this.comments,
  });
}

// ==========================================
// 2. MAIN APP WRAPPER (To make it runnable)
// ==========================================

void main() {
  runApp(const LearnifyApp());
}

class LearnifyApp extends StatelessWidget {
  const LearnifyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Learnify Forum',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const ForumPage(),
    );
  }
}

// ==========================================
// 3. FORUM PAGE (Local State Implementation)
// ==========================================

class ForumPage extends StatefulWidget {
  const ForumPage({super.key});

  @override
  State<ForumPage> createState() => _ForumPageState();
}

class _ForumPageState extends State<ForumPage> {
  final TextEditingController _postController = TextEditingController();
  final TextEditingController _searchController = TextEditingController();

  String _searchQuery = "";

  // Dummy current user for "Me" identification
  final String currentUserName = "Ali bin Ahmad";

  // Local state storage for posts
  final List<ForumPost> _allPosts = [
    ForumPost(
      id: "1",
      author: "Siti Sarah",
      content: "Siapa tahu cara nak selesaikan Quadratic Equation guna formula?",
      timestamp: DateTime.now().subtract(const Duration(hours: 2)),
      likeCount: 5,
      comments: [
        ForumComment(
          id: "c1",
          author: "Dr. Zulkifli",
          text: "Guna rumus -b ± sqrt(b^2 - 4ac) / 2a",
          timestamp: DateTime.now().subtract(const Duration(hours: 1)),
        ),
      ],
    ),
    ForumPost(
      id: "2",
      author: "Ali bin Ahmad",
      content: "Ada sesiapa nak buat study group untuk exam Biologi minggu depan?",
      timestamp: DateTime.now().subtract(const Duration(minutes: 45)),
      likeCount: 12,
      comments: [],
    ),
  ];

  // Logic: Filter posts based on search query
  List<ForumPost> get _filteredPosts {
    if (_searchQuery.isEmpty) return _allPosts;
    return _allPosts
        .where((post) =>
    post.content.toLowerCase().contains(_searchQuery.toLowerCase()) ||
        post.author.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }

  // Logic: Add new post
  void _addPost() {
    if (_postController.text
        .trim()
        .isEmpty) return;
    setState(() {
      _allPosts.insert(
        0,
        ForumPost(
          id: DateTime
              .now()
              .millisecondsSinceEpoch
              .toString(),
          author: currentUserName,
          content: _postController.text.trim(),
          timestamp: DateTime.now(),
          comments: [],
        ),
      );
      _postController.clear();
    });
    FocusScope.of(context).unfocus();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Post berjaya dihantar!"),
          backgroundColor: Colors.green),
    );
  }

  // Logic: Delete post with confirmation
  void _deletePost(String id) {
    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text("Padam Post"),
            content: const Text("Adakah anda pasti mahu memadam post ini?"),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context),
                  child: const Text("Batal")),
              TextButton(
                onPressed: () {
                  setState(() => _allPosts.removeWhere((p) => p.id == id));
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Post dipadam.")));
                },
                child: const Text("Padam", style: TextStyle(color: Colors.red)),
              ),
            ],
          ),
    );
  }

  // Logic: Toggle Like
  void _toggleLike(ForumPost post) {
    setState(() {
      if (post.isLiked) {
        post.likeCount--;
        post.isLiked = false;
      } else {
        post.likeCount++;
        post.isLiked = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    const primaryPurple = Colors.deepPurple;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        title: const Text("Discussion Forum",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: primaryPurple,
        centerTitle: true,
        elevation: 0,
        // The prompt asked for functional back button
        leading: Navigator.canPop(context) ? IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ) : null,
      ),
      body: Column(
        children: [
          // 1. Search Bar
          Container(
            padding: const EdgeInsets.all(12),
            color: primaryPurple,
            child: TextField(
              controller: _searchController,
              onChanged: (val) => setState(() => _searchQuery = val),
              decoration: InputDecoration(
                hintText: "Cari soalan atau pengguna...",
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none),
              ),
            ),
          ),

          // 2. Create Post Section
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.black12, blurRadius: 4, offset: Offset(0, 2))
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _postController,
                    decoration: const InputDecoration(
                        hintText: "Apa soalan anda?", border: InputBorder.none),
                  ),
                ),
                ElevatedButton(
                  onPressed: _addPost,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryPurple,
                    shape: const StadiumBorder(),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                  ),
                  child: const Text("Post", style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          ),

          // 3. Forum Feed
          Expanded(
            child: _filteredPosts.isEmpty
                ? const Center(child: Text("Tiada post ditemui."))
                : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _filteredPosts.length,
              itemBuilder: (context, index) {
                final post = _filteredPosts[index];
                return _buildPostCard(post);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPostCard(ForumPost post) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(backgroundColor: Colors.deepPurple.shade100,
                    child: Text(post.author[0])),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(post.author,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(DateFormat('hh:mm a, dd MMM').format(post.timestamp),
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 11)),
                    ],
                  ),
                ),
                // Only owner can delete (logic simplified to match current user name)
                if (post.author == currentUserName)
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    onPressed: () => _deletePost(post.id),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Text(post.content,
                style: const TextStyle(fontSize: 15, height: 1.4)),
            const SizedBox(height: 12),
            const Divider(),
            Row(
              children: [
                // Like Button
                TextButton.icon(
                  onPressed: () => _toggleLike(post),
                  icon: Icon(
                      post.isLiked ? Icons.favorite : Icons.favorite_border,
                      color: post.isLiked ? Colors.red : Colors.grey),
                  label: Text("${post.likeCount} Like",
                      style: TextStyle(
                          color: post.isLiked ? Colors.red : Colors.grey)),
                ),
                const SizedBox(width: 16),
                // Comment Button
                TextButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) =>
                          ForumCommentsPage(
                              post: post, currentUserName: currentUserName)),
                    ).then((_) => setState(() {})); // Update when coming back
                  },
                  icon: const Icon(
                      Icons.chat_bubble_outline, color: Colors.grey),
                  label: Text("${post.comments.length} Komen",
                      style: const TextStyle(color: Colors.grey)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 4. COMMENTS PAGE
// ==========================================

class ForumCommentsPage extends StatefulWidget {
  final ForumPost post;
  final String currentUserName;

  const ForumCommentsPage(
      {super.key, required this.post, required this.currentUserName});

  @override
  State<ForumCommentsPage> createState() => _ForumCommentsPageState();
}

class _ForumCommentsPageState extends State<ForumCommentsPage> {
  final TextEditingController _commentController = TextEditingController();

  // Logic: Add Comment
  void _addComment() {
    if (_commentController.text
        .trim()
        .isEmpty) return;
    setState(() {
      widget.post.comments.add(
        ForumComment(
          id: DateTime
              .now()
              .millisecondsSinceEpoch
              .toString(),
          author: widget.currentUserName,
          text: _commentController.text.trim(),
          timestamp: DateTime.now(),
        ),
      );
      _commentController.clear();
    });
  }

  // Logic: Edit Comment
  void _editComment(int index) {
    final TextEditingController editCtrl = TextEditingController(
        text: widget.post.comments[index].text);
    showDialog(
      context: context,
      builder: (context) =>
          AlertDialog(
            title: const Text("Edit Komen"),
            content: TextField(controller: editCtrl,
                decoration: const InputDecoration(hintText: "Tulis semula...")),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context),
                  child: const Text("Batal")),
              TextButton(
                onPressed: () {
                  if (editCtrl.text
                      .trim()
                      .isNotEmpty) {
                    setState(() =>
                    widget.post.comments[index].text = editCtrl.text.trim());
                  }
                  Navigator.pop(context);
                },
                child: const Text("Simpan"),
              ),
            ],
          ),
    );
  }

  // Logic: Delete Comment
  void _deleteComment(int index) {
    setState(() => widget.post.comments.removeAt(index));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Komen"),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          // Original Post Info
          Container(
            padding: const EdgeInsets.all(16),
            width: double.infinity,
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.post.author, style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.deepPurple)),
                const SizedBox(height: 4),
                Text(widget.post.content, style: const TextStyle(fontSize: 16)),
              ],
            ),
          ),
          const Divider(height: 1),

          // Comments List
          Expanded(
            child: widget.post.comments.isEmpty
                ? const Center(child: Text("Belum ada komen lagi."))
                : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: widget.post.comments.length,
              itemBuilder: (context, index) {
                final comment = widget.post.comments[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(comment.author, style: const TextStyle(
                        fontSize: 13, fontWeight: FontWeight.bold)),
                    subtitle: Text(comment.text),
                    trailing: comment.author == widget.currentUserName
                        ? PopupMenuButton<String>(
                      onSelected: (val) {
                        if (val == 'edit') _editComment(index);
                        if (val == 'delete') _deleteComment(index);
                      },
                      itemBuilder: (context) =>
                      [
                        const PopupMenuItem(value: 'edit', child: Text("Edit")),
                        const PopupMenuItem(value: 'delete',
                            child: Text(
                                "Padam", style: TextStyle(color: Colors.red))),
                      ],
                    )
                        : null,
                  ),
                );
              },
            ),
          ),

          // Input Field
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [
                BoxShadow(color: Colors.black12,
                    blurRadius: 4,
                    offset: const Offset(0, -2))
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _commentController,
                    decoration: InputDecoration(
                      hintText: "Tulis komen anda...",
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(25)),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.deepPurple),
                  onPressed: _addComment,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}