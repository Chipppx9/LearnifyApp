import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'dart:async';

// ==========================================
// 1. DATA MODELS
// ==========================================

class VideoLesson {
  final String id;
  final String title;
  final String subject;
  final String duration;
  final String thumbnail;
  final String videoUrl;
  final String description;
  double progress;
  bool isCompleted;
  bool isBookmarked;
  bool isOffline;

  VideoLesson({
    required this.id,
    required this.title,
    required this.subject,
    required this.duration,
    required this.thumbnail,
    required this.videoUrl,
    required this.description,
    this.progress = 0.0,
    this.isCompleted = false,
    this.isBookmarked = false,
    this.isOffline = false,
  });
}

class Note {
  String id;
  String content;
  DateTime timestamp;

  Note({required this.id, required this.content, required this.timestamp});
}

// ==========================================
// 2. VIDEO CLASS LIST PAGE
// ==========================================

class VideoClassPage extends StatefulWidget {
  const VideoClassPage({super.key});

  @override
  State<VideoClassPage> createState() => _VideoClassPageState();
}

class _VideoClassPageState extends State<VideoClassPage> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";
  String _selectedFilter = "All";

  final List<VideoLesson> _allVideos = [
    VideoLesson(
      id: "1",
      title: "Introduction to Algebra",
      subject: "Mathematics",
      duration: "15 min",
      thumbnail: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400",
      videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
      description: "Learn the fundamentals of Algebra, including variables, equations, and expressions.",
      progress: 0.45,
    ),
    VideoLesson(
      id: "2",
      title: "Human Digestive System",
      subject: "Science",
      duration: "20 min",
      thumbnail: "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=400",
      videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
      description: "Explore the journey of food through the human body and how organs work together.",
    ),
    VideoLesson(
      id: "3",
      title: "Grammar Basics",
      subject: "English",
      duration: "12 min",
      thumbnail: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=400",
      videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4",
      description: "Master the basic rules of English grammar, focusing on parts of speech and sentence structure.",
      isCompleted: true,
      progress: 1.0,
    ),
    VideoLesson(
      id: "4",
      title: "Quadratic Equations",
      subject: "Mathematics",
      duration: "18 min",
      thumbnail: "https://images.unsplash.com/photo-1509228468518-180dd4864904?w=400",
      videoUrl: "https://flutter.github.io/assets-for-api-docs/assets/videos/butterfly.mp4",
      description: "A deep dive into solving quadratic equations using factoring and formulas.",
    ),
  ];

  List<VideoLesson> get _filteredVideos {
    return _allVideos.where((v) {
      final matchesSearch = v.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          v.subject.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesFilter = _selectedFilter == "All" || v.subject == _selectedFilter;
      return matchesSearch && matchesFilter;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    const primaryColor = Colors.deepPurple;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        title: const Text("Learning Videos", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: primaryColor,
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Search Section
          Container(
            padding: const EdgeInsets.all(16),
            color: primaryColor,
            child: TextField(
              controller: _searchController,
              onChanged: (val) => setState(() => _searchQuery = val),
              decoration: InputDecoration(
                hintText: "Search title or subject...",
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
              ),
            ),
          ),
          
          // Filter Section
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: ["All", "Mathematics", "Science", "English"].map((filter) {
                final isSelected = _selectedFilter == filter;
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(filter),
                    selected: isSelected,
                    selectedColor: primaryColor,
                    labelStyle: TextStyle(color: isSelected ? Colors.white : Colors.black),
                    onSelected: (selected) {
                      setState(() => _selectedFilter = filter);
                    },
                  ),
                );
              }).toList(),
            ),
          ),

          // Video List
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _filteredVideos.length,
              itemBuilder: (context, index) {
                final video = _filteredVideos[index];
                return _buildVideoCard(video);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoCard(VideoLesson video) {
    String status = "Not Started";
    Color statusColor = Colors.grey;
    if (video.isCompleted) {
      status = "Completed";
      statusColor = Colors.green;
    } else if (video.progress > 0) {
      status = "In Progress";
      statusColor = Colors.orange;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 2,
      child: InkWell(
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => VideoPlayerPage(
                videos: _allVideos,
                initialIndex: _allVideos.indexOf(video),
              ),
            ),
          );
          setState(() {}); // Refresh list on return
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                  child: Image.network(video.thumbnail, height: 160, width: double.infinity, fit: BoxFit.cover),
                ),
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: Colors.black87, borderRadius: BorderRadius.circular(8)),
                    child: Text(video.duration, style: const TextStyle(color: Colors.white, fontSize: 12)),
                  ),
                ),
                if (video.isCompleted)
                  const Positioned(
                    top: 12,
                    right: 12,
                    child: CircleAvatar(
                      backgroundColor: Colors.green,
                      radius: 15,
                      child: Icon(Icons.check, color: Colors.white, size: 20),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(video.subject, style: const TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold, fontSize: 12)),
                      Text(status, style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(video.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  LinearProgressIndicator(
                    value: video.progress,
                    backgroundColor: Colors.grey[200],
                    color: Colors.deepPurple,
                    minHeight: 6,
                    borderRadius: BorderRadius.circular(10),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 3. VIDEO PLAYER PAGE
// ==========================================

class VideoPlayerPage extends StatefulWidget {
  final List<VideoLesson> videos;
  final int initialIndex;

  const VideoPlayerPage({super.key, required this.videos, required this.initialIndex});

  @override
  State<VideoPlayerPage> createState() => _VideoPlayerPageState();
}

class _VideoPlayerPageState extends State<VideoPlayerPage> {
  late int _currentIndex;
  VideoPlayerController? _videoPlayerController;
  ChewieController? _chewieController;
  final List<Note> _notes = [];
  final TextEditingController _noteInputController = TextEditingController();
  bool _isCompletedDialogShown = false;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
    _initializePlayer();
  }

  Future<void> _initializePlayer() async {
    final video = widget.videos[_currentIndex];
    _videoPlayerController = VideoPlayerController.networkUrl(Uri.parse(video.videoUrl));
    
    await _videoPlayerController!.initialize();

    _chewieController = ChewieController(
      videoPlayerController: _videoPlayerController!,
      autoPlay: true,
      looping: false,
      aspectRatio: _videoPlayerController!.value.aspectRatio,
      materialProgressColors: ChewieProgressColors(
        playedColor: Colors.deepPurple,
        handleColor: Colors.deepPurpleAccent,
        backgroundColor: Colors.grey,
        bufferedColor: Colors.grey[300]!,
      ),
    );

    _videoPlayerController!.addListener(_onVideoProgress);
    setState(() {});
  }

  void _onVideoProgress() {
    if (_videoPlayerController == null || !_videoPlayerController!.value.isInitialized) return;

    final duration = _videoPlayerController!.value.duration;
    final position = _videoPlayerController!.value.position;
    final progress = position.inMilliseconds / duration.inMilliseconds;

    setState(() {
      widget.videos[_currentIndex].progress = progress;
      
      // Auto-complete at 90%
      if (progress >= 0.90 && !widget.videos[_currentIndex].isCompleted) {
        widget.videos[_currentIndex].isCompleted = true;
        widget.videos[_currentIndex].progress = 1.0;
        _showCompletionReward();
      }
    });
  }

  void _showCompletionReward() {
    if (_isCompletedDialogShown) return;
    _isCompletedDialogShown = true;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Column(
          children: [
            Icon(Icons.emoji_events, color: Colors.amber, size: 60),
            SizedBox(height: 10),
            Text("Congratulations!", style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: const Text("Lesson Completed Successfully.", textAlign: TextAlign.center),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Back To Course"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _nextLesson();
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
            child: const Text("Continue Learning"),
          ),
        ],
      ),
    );
  }

  void _nextLesson() {
    if (_currentIndex < widget.videos.length - 1) {
      _changeLesson(_currentIndex + 1);
    }
  }

  void _previousLesson() {
    if (_currentIndex > 0) {
      _changeLesson(_currentIndex - 1);
    }
  }

  void _changeLesson(int index) async {
    _isCompletedDialogShown = false;
    _videoPlayerController?.removeListener(_onVideoProgress);
    await _videoPlayerController?.dispose();
    _chewieController?.dispose();
    
    setState(() {
      _currentIndex = index;
      _videoPlayerController = null;
      _chewieController = null;
    });
    _initializePlayer();
  }

  @override
  void dispose() {
    _videoPlayerController?.removeListener(_onVideoProgress);
    _videoPlayerController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // Logic: Bookmark
  void _toggleBookmark() {
    setState(() {
      widget.videos[_currentIndex].isBookmarked = !widget.videos[_currentIndex].isBookmarked;
    });
  }

  // Logic: Download (Mock)
  void _downloadMock() {
    setState(() {
      widget.videos[_currentIndex].isOffline = true;
    });
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Download"),
        content: const Text("Video added to offline list"),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK"))],
      ),
    );
  }

  // Logic: Notes
  void _addNote() {
    if (_noteInputController.text.trim().isEmpty) return;
    setState(() {
      _notes.insert(0, Note(
        id: DateTime.now().toString(),
        content: _noteInputController.text.trim(),
        timestamp: DateTime.now(),
      ));
      _noteInputController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final video = widget.videos[_currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Lesson Player"),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(video.isBookmarked ? Icons.bookmark : Icons.bookmark_border),
            onPressed: _toggleBookmark,
          ),
          IconButton(
            icon: Icon(video.isOffline ? Icons.download_done : Icons.download),
            onPressed: _downloadMock,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Video Section
            AspectRatio(
              aspectRatio: 16 / 9,
              child: _chewieController != null && _chewieController!.videoPlayerController.value.isInitialized
                  ? Chewie(controller: _chewieController!)
                  : const Center(child: CircularProgressIndicator()),
            ),

            // Video Info Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(video.subject, style: const TextStyle(color: Colors.deepPurple, fontWeight: FontWeight.bold)),
                      Text(video.duration, style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(video.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(video.description, style: const TextStyle(color: Colors.grey, fontSize: 14)),
                ],
              ),
            ),

            const Divider(),

            // Lesson Navigation
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  TextButton.icon(
                    onPressed: _currentIndex > 0 ? _previousLesson : null,
                    icon: const Icon(Icons.skip_previous),
                    label: const Text("Previous Lesson"),
                  ),
                  TextButton.icon(
                    onPressed: _currentIndex < widget.videos.length - 1 ? _nextLesson : null,
                    icon: const Icon(Icons.skip_next),
                    label: const Text("Next Lesson"),
                  ),
                ],
              ),
            ),

            const Divider(),

            // Notes Section
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("Study Notes", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _noteInputController,
                          decoration: InputDecoration(
                            hintText: "Take a note...",
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        onPressed: _addNote,
                        icon: const Icon(Icons.add_circle, color: Colors.deepPurple, size: 32),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _notes.length,
                    itemBuilder: (context, index) {
                      final note = _notes[index];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 8),
                        child: ListTile(
                          title: Text(note.content),
                          subtitle: Text("${note.timestamp.hour}:${note.timestamp.minute}"),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, size: 20),
                                onPressed: () {
                                  // Edit logic simple implementation
                                  _noteInputController.text = note.content;
                                  setState(() => _notes.removeAt(index));
                                },
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                                onPressed: () => setState(() => _notes.removeAt(index)),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
