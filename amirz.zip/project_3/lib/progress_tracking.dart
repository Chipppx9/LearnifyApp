import 'package:flutter/material.dart';

// ==========================================
// MODELS
// ==========================================

class Subject {
  final String name;
  final double progress; // 0.0 to 1.0
  final int score;
  final int completedLessons;
  final int totalLessons;
  final Color color;
  final IconData icon;

  Subject({
    required this.name,
    required this.progress,
    required this.score,
    required this.completedLessons,
    required this.totalLessons,
    required this.color,
    required this.icon,
  });
}

class BadgeItem {
  final String name;
  final IconData icon;
  final String description;
  final Color color;

  BadgeItem({
    required this.name,
    required this.icon,
    required this.description,
    required this.color,
  });
}

// ==========================================
// PROGRESS TRACKING PAGE
// ==========================================

class ProgressTrackingPage extends StatefulWidget {
  const ProgressTrackingPage({super.key});

  @override
  State<ProgressTrackingPage> createState() => _ProgressTrackingPageState();
}

class _ProgressTrackingPageState extends State<ProgressTrackingPage> {
  // Dummy Data for Statistics
  final double overallProgress = 0.72;
  final String studyHours = "42.5h";
  final String lessonsText = "48/60";
  final String avgScore = "81%";

  final List<Subject> subjects = [
    Subject(
      name: 'Mathematics',
      progress: 0.85,
      score: 92,
      completedLessons: 17,
      totalLessons: 20,
      color: Colors.blue,
      icon: Icons.calculate,
    ),
    Subject(
      name: 'Science',
      progress: 0.70,
      score: 78,
      completedLessons: 14,
      totalLessons: 20,
      color: Colors.green,
      icon: Icons.science,
    ),
    Subject(
      name: 'English',
      progress: 0.60,
      score: 85,
      completedLessons: 12,
      totalLessons: 20,
      color: Colors.orange,
      icon: Icons.language,
    ),
  ];

  final List<BadgeItem> badges = [
    BadgeItem(
      name: '7 Days Streak',
      icon: Icons.local_fire_department,
      description: 'You studied for 7 consecutive days! Keep up the momentum.',
      color: Colors.orange,
    ),
    BadgeItem(
      name: 'Fast Learner',
      icon: Icons.bolt,
      description: 'Completed 5 lessons in a single day. Incredible speed!',
      color: Colors.blue,
    ),
    BadgeItem(
      name: 'Perfect Score',
      icon: Icons.star,
      description: 'Achieved 100% in a quiz. Exceptional work!',
      color: Colors.amber,
    ),
    BadgeItem(
      name: 'Contributor',
      icon: Icons.groups,
      description: 'Helped 10 fellow students in the discussion forum.',
      color: Colors.purple,
    ),
  ];

  void _showBadgeDetail(BadgeItem badge) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Column(
          children: [
            Icon(badge.icon, size: 60, color: badge.color),
            const SizedBox(height: 10),
            Text(badge.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        content: Text(badge.description, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
        actions: [
          Center(
            child: TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Awesome!', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
          )
        ],
      ),
    );
  }

  void _exportReport(String type) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Generating $type Report...'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    const primaryPurple = Colors.deepPurple;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        title: const Text('My Progress', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: primaryPurple,
        centerTitle: true,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 1. Overall Progress Card
            _buildOverallProgressCard(primaryPurple),
            const SizedBox(height: 25),

            // 2. Study Statistics Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatItem('Study Hours', studyHours, Icons.timer, Colors.blue),
                _buildStatItem('Lessons', lessonsText, Icons.menu_book, Colors.orange),
                _buildStatItem('Avg Score', avgScore, Icons.analytics, Colors.green),
              ],
            ),
            const SizedBox(height: 30),

            // 3. Subject Performance List
            const Text('Subject Performance', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            ...subjects.map((s) => _buildSubjectCard(s)).toList(),
            const SizedBox(height: 30),

            // 4. Achievement Badges Row
            const Text('Achievements', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            _buildBadgesRow(),
            const SizedBox(height: 40),

            // 5. Export Buttons
            const Text('Export Learning Report', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 15),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _exportReport('PDF'),
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('Export PDF'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.shade400,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _exportReport('Excel'),
                    icon: const Icon(Icons.table_chart),
                    label: const Text('Export Excel'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade400,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildOverallProgressCard(Color color) {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Row(
          children: [
            SizedBox(
              height: 90,
              width: 90,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CircularProgressIndicator(
                    value: overallProgress,
                    strokeWidth: 10,
                    backgroundColor: color.withOpacity(0.1),
                    valueColor: AlwaysStoppedAnimation<Color>(color),
                    strokeCap: StrokeCap.round,
                  ),
                  Text(
                    '${(overallProgress * 100).toInt()}%',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 25),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Overall Progress', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 4),
                  Text('You are doing great! Complete 12 more lessons to reach your target.',
                    style: TextStyle(color: Colors.grey, fontSize: 13)),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Container(
      width: 100,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10)],
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildSubjectCard(Subject s) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SubjectDetailPage(subject: s)),
        );
      },
      child: Card(
        margin: const EdgeInsets.only(bottom: 15),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(s.icon, color: s.color, size: 20),
                      const SizedBox(width: 10),
                      Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                  Text('${(s.progress * 100).toInt()}%', style: TextStyle(color: s.color, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: s.progress,
                  minHeight: 8,
                  backgroundColor: s.color.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(s.color),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBadgesRow() {
    return SizedBox(
      height: 100,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: badges.length,
        itemBuilder: (context, index) {
          final b = badges[index];
          return GestureDetector(
            onTap: () => _showBadgeDetail(b),
            child: Padding(
              padding: const EdgeInsets.only(right: 20),
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5)],
                    ),
                    child: Icon(b.icon, color: b.color, size: 30),
                  ),
                  const SizedBox(height: 8),
                  Text(b.name, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ==========================================
// SUBJECT DETAIL PAGE
// ==========================================

class SubjectDetailPage extends StatelessWidget {
  final Subject subject;
  const SubjectDetailPage({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        title: Text('${subject.name} Details'),
        backgroundColor: subject.color,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const SizedBox(height: 20),
            Center(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    height: 150,
                    width: 150,
                    child: CircularProgressIndicator(
                      value: subject.progress,
                      strokeWidth: 15,
                      backgroundColor: subject.color.withOpacity(0.1),
                      valueColor: AlwaysStoppedAnimation<Color>(subject.color),
                      strokeCap: StrokeCap.round,
                    ),
                  ),
                  Column(
                    children: [
                      Text(
                        '${(subject.progress * 100).toInt()}%',
                        style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: subject.color),
                      ),
                      const Text('Progress', style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),

            _detailRow(Icons.analytics, 'Current Score', '${subject.score}%', subject.color),
            const SizedBox(height: 15),
            _detailRow(Icons.menu_book, 'Lessons Completed', '${subject.completedLessons} / ${subject.totalLessons}', subject.color),
            const SizedBox(height: 15),
            _detailRow(Icons.check_circle, 'Completion Status', subject.progress >= 1.0 ? 'Completed' : 'On Track', subject.color),

            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: subject.color,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                ),
                child: const Text('Back to Progress', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _detailRow(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10)],
      ),
      child: Row(
        children: [
          Icon(icon, color: color),
          const SizedBox(width: 15),
          Text(label, style: const TextStyle(fontSize: 16)),
          const Spacer(),
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
