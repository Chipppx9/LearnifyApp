import 'package:flutter/material.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({super.key});

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  // State variables
  String? _selectedPlan = 'Premium Plan';
  double _planPrice = 99.0;
  String? _selectedMethod;
  final TextEditingController _promoController = TextEditingController();
  double _discountPercentage = 0.0;
  double _discountAmount = 0.0;
  bool _isApplied = false;

  final List<Map<String, dynamic>> _plans = [
    {'name': 'Monthly Basic', 'price': 49.0},
    {'name': 'Premium Plan', 'price': 99.0},
    {'name': 'Premium Plus', 'price': 149.0},
  ];

  final List<Map<String, dynamic>> _paymentMethods = [
    {'name': 'Online Banking', 'icon': Icons.account_balance},
    {'name': 'Debit Card', 'icon': Icons.credit_card},
    {'name': 'Credit Card', 'icon': Icons.payment},
    {'name': 'E-Wallet', 'icon': Icons.account_balance_wallet},
  ];

  final List<Map<String, dynamic>> _history = [
    {'date': '01 Oct 2023', 'plan': 'Premium Plan', 'amount': 99.0, 'status': 'Success'},
    {'date': '01 Sep 2023', 'plan': 'Premium Plan', 'amount': 99.0, 'status': 'Success'},
  ];

  void _applyPromo() {
    String code = _promoController.text.trim().toUpperCase();
    setState(() {
      if (code == 'SAVE10') {
        _discountPercentage = 0.10;
        _isApplied = true;
      } else if (code == 'WELCOME20') {
        _discountPercentage = 0.20;
        _isApplied = true;
      } else {
        _discountPercentage = 0.0;
        _isApplied = false;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invalid Promo Code')),
        );
      }
      _calculateTotal();
    });
  }

  void _calculateTotal() {
    _discountAmount = _planPrice * _discountPercentage;
  }

  double get _finalTotal => _planPrice - _discountAmount;

  void _processPayment() {
    if (_selectedMethod == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a payment method')),
      );
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(child: CircularProgressIndicator()),
    );

    // Simulate Firebase storage and processing
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pop(context); // Close loading
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Icon(Icons.check_circle, color: Colors.green, size: 60),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Payment Successful!', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              const SizedBox(height: 8),
              Text('Your $_selectedPlan is now active.', textAlign: TextAlign.center),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Great!'),
            )
          ],
        ),
      );
      
      setState(() {
        _history.insert(0, {
          'date': 'Today',
          'plan': _selectedPlan,
          'amount': _finalTotal,
          'status': 'Success'
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    const primaryPurple = Colors.deepPurple;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Payment & Subscription', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: primaryPurple,
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Plan Selection
            const Text('Choose Your Plan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ..._plans.map((plan) {
              bool isSelected = _selectedPlan == plan['name'];
              return GestureDetector(
                onTap: () {
                  setState(() {
                    _selectedPlan = plan['name'];
                    _planPrice = plan['price'];
                    _calculateTotal();
                  });
                },
                child: Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(color: isSelected ? primaryPurple : Colors.transparent, width: 2),
                  ),
                  elevation: isSelected ? 4 : 1,
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    title: Text(plan['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('RM ${plan['price'].toStringAsFixed(0)} / month'),
                    trailing: isSelected ? const Icon(Icons.check_circle, color: primaryPurple) : null,
                  ),
                ),
              );
            }).toList(),

            const SizedBox(height: 24),
            // Payment Method
            const Text('Payment Method', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 2.5,
              ),
              itemCount: _paymentMethods.length,
              itemBuilder: (context, index) {
                final method = _paymentMethods[index];
                bool isSelected = _selectedMethod == method['name'];
                return GestureDetector(
                  onTap: () => setState(() => _selectedMethod = method['name']),
                  child: Container(
                    decoration: BoxDecoration(
                      color: !isSelected ? Colors.white : primaryPurple.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: !isSelected ? Colors.grey.shade300 : primaryPurple),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(method['icon'], color: isSelected ? primaryPurple : Colors.grey),
                        const SizedBox(width: 8),
                        Text(method['name'], style: TextStyle(
                          color: isSelected ? primaryPurple : Colors.black87,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          fontSize: 12,
                        )),
                      ],
                    ),
                  ),
                );
              },
            ),

            const SizedBox(height: 24),
            // Promo Code
            const Text('Promo Code', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _promoController,
                    decoration: InputDecoration(
                      hintText: 'Enter Code (e.g. SAVE10)',
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton(
                  onPressed: _applyPromo,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryPurple,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Apply'),
                ),
              ],
            ),

            const SizedBox(height: 32),
            // Payment Summary
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10)],
              ),
              child: Column(
                children: [
                  _summaryRow('Original Price', 'RM ${_planPrice.toStringAsFixed(2)}'),
                  if (_discountAmount > 0)
                    _summaryRow('Discount (${(_discountPercentage * 100).toInt()}%)', '- RM ${_discountAmount.toStringAsFixed(2)}', isDiscount: true),
                  const Divider(height: 24),
                  _summaryRow('Total Payment', 'RM ${_finalTotal.toStringAsFixed(2)}', isTotal: true),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      onPressed: _processPayment,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryPurple,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                        elevation: 0,
                      ),
                      child: const Text('Pay Now', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),
            // Subscription History
            const Text('Subscription History', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _history.length,
              itemBuilder: (context, index) {
                final h = _history[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    title: Text(h['plan'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(h['date']),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('RM ${h['amount'].toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text(h['status'], style: const TextStyle(color: Colors.green, fontSize: 12)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool isTotal = false, bool isDiscount = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(
            fontSize: isTotal ? 18 : 14,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            color: Colors.grey.shade700,
          )),
          Text(value, style: TextStyle(
            fontSize: isTotal ? 20 : 14,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            color: isDiscount ? Colors.green : (isTotal ? Colors.deepPurple : Colors.black),
          )),
        ],
      ),
    );
  }
}
